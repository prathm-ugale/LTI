package com.examly.springapp.service;
 
import java.util.List;
 
import com.examly.springapp.model.Feedback;
 
public interface FeedbackService {
 
    public List<Feedback> viewFeedback();

    public Feedback addFeedback(Feedback feedback);

    public List<Feedback> getFeedbackByUserId(Integer userId);

    public Feedback deleteFeedback(int feedbackId);
 
 
}