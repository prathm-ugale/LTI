package com.examly.springapp.service;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.examly.springapp.exceptions.CropNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Crop;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.CropRepo;
import com.examly.springapp.repository.UserRepo;

import jakarta.persistence.EntityNotFoundException;
 
 
@Service

public class CropServiceImpl implements CropService {
 
    @Autowired
     private CropRepo cropRepo;
 
    @Autowired
    private UserRepo userRepo;
 
    @Override
    public Crop addCrop(Crop crop) {
        Optional<User> getUser=userRepo.findById(crop.getUser().getUserId());
        crop.setUser(getUser.get());
        Optional<Crop> getCrop=cropRepo.findByPlantingDateAndCropName(crop.getPlantingDate(), crop.getCropName());
        if(getCrop.isPresent()){
            throw new EntityNotFoundException("Duplicate PlantingDate exists on same plant name");
        }
        return cropRepo.save(crop);
    }
 
   
    public List<Crop> getCropByUserId(int userId) {
       Optional<User> optCrop=userRepo.findById(userId);
       if(optCrop.isEmpty()){
        throw new UserNotFoundException("User not found with userId "+userId);
       }
        List<Crop> allCrop=cropRepo.findByUser(optCrop.get());
        return allCrop;
 
    }
 
    @Override
    public Crop getCropById(Long cropId) {
        Optional<Crop> optCrop=cropRepo.findById(cropId);
        if(optCrop.isPresent()){
            return optCrop.get();
        }else{
            throw new CropNotFoundException("Crop doesn't exist");
        }
    }
 
    @Override
    public Crop updateCropById(Long cropId, Crop crop) {
        Optional<Crop> optCrop=cropRepo.findById(cropId);
        if(optCrop.isEmpty()){
            throw new CropNotFoundException("crop with crop ID "+cropId+" not Exist");
        }
 
         Crop cropData=optCrop.get();
         cropData.setCropName(crop.getCropName());
         cropData.setCropType(crop.getCropType());
         cropData.setDescription(crop.getDescription());
         cropData.setPlantingDate(crop.getPlantingDate());
        
 
        return cropRepo.save(cropData);
 
    }
 
    @Override
    public Crop deleteCropById(Long cropId) {
        Optional<Crop> optCrop=cropRepo.findById(cropId);
        if(optCrop.isEmpty()){
            throw new CropNotFoundException("crop with crop ID "+cropId+" not Exist");
        }
        else{
            cropRepo.deleteById(cropId);
            return optCrop.get();
        }
    }
 
    public List<Crop> getAllCrop() {
        List<Crop> cropList=cropRepo.findAll();
        return cropList;
    }
 
 
}
