package com.examly.springapp.exceptions;

public class FeedbackNotFoundException extends RuntimeException{
    
    public FeedbackNotFoundException(String message, Throwable cause) 
    {
        super(message, cause);
    }
    
    public FeedbackNotFoundException(Throwable cause) 
    {
        super(cause);
    }

    public FeedbackNotFoundException(String message) 
    {
        super(message);
    }
    
}
