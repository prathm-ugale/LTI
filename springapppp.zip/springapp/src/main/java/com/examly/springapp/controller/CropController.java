package com.examly.springapp.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
 
import com.examly.springapp.exceptions.CropNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Crop;
import com.examly.springapp.service.CropService;

import jakarta.persistence.EntityNotFoundException;
 
@RestController

@CrossOrigin

public class CropController {
 
    @Autowired
    
    private  CropService cropService;
 
    @PostMapping("/api/crop")
    public ResponseEntity<?> addCrop(@RequestBody Crop crop){
        try{
            Crop newCrop=cropService.addCrop(crop);
            return ResponseEntity.status(201).body(newCrop);
        }catch(EntityNotFoundException e){
          return ResponseEntity.status(500).body("Duplicate plant found");
        }
        
    }
 
 
    @GetMapping("/api/crop")
    public ResponseEntity<?> getAllCrop(){
        List<Crop> cropList=cropService.getAllCrop();
        return ResponseEntity.status(201).body(cropList);
    }
 
    @GetMapping("/api/crop/user/{userId}")
    public ResponseEntity<?> getCropByUserId(@PathVariable int userId){
        try{
            List<Crop> cropList = cropService.getCropByUserId(userId);
            return ResponseEntity.status(200).body(cropList);
        }catch(UserNotFoundException e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
 
    }
    @GetMapping("/api/crop/{cropId}")
    public ResponseEntity<?> getCropById(@PathVariable Long cropId){
        try{
            Crop crops=cropService.getCropById(cropId);
            return ResponseEntity.status(200).body(crops);
        }catch(CropNotFoundException e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
 
    }
 
    @PutMapping("/api/crop/{cropId}")
    public ResponseEntity<?> updateCropById(@PathVariable Long cropId ,@RequestBody Crop crop){
        try{
            Crop updatedCrop=cropService.updateCropById(cropId,crop);
            return ResponseEntity.status(200).body(updatedCrop);
        }catch(CropNotFoundException e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
 
    }
 
    @DeleteMapping("/api/crop/{cropId}")
    public ResponseEntity<?> deleteCropById(@PathVariable Long cropId){
        try{
            Crop crop=cropService.deleteCropById(cropId);
            return ResponseEntity.status(200).body(crop);
        }catch(CropNotFoundException e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
 
    }
}