package com.examly.springapp.model;

import java.time.LocalDate;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity

public class Crop {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cropId;
    private String cropName;
    private String cropType;
    private String description;
    private LocalDate plantingDate;
    
    @ManyToOne
    @JoinColumn(name="userId")
    private User user;
    
    @OneToMany( mappedBy = "crop",cascade = CascadeType.ALL)
    private List<Request> request;

    public Crop() {
    }

    public Crop(Long cropId, String cropName, String cropType, String description, LocalDate plantingDate, User user) {
        this.cropId = cropId;
        this.cropName = cropName;
        this.cropType = cropType;
        this.description = description;
        this.plantingDate = plantingDate;
        this.user = user;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(LocalDate plantingDate) {
        this.plantingDate = plantingDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "Crop [cropId=" + cropId + ", cropName=" + cropName + ", cropType=" + cropType + ", description="
                + description + ", plantingDate=" + plantingDate + ", user=" + user + "]";
    }

    
}
