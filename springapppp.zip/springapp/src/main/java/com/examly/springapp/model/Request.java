package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity

public class Request {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long requestId;
    private int quantity;
    private String status;
    private LocalDate requestDate;
    private String rejectionReason;

    @ManyToOne
    @JoinColumn(name="agroChemicalId")
    private AgroChemical agroChemical;

    @ManyToOne
    @JoinColumn(name="userId")
    private User user;
    
    @ManyToOne
    @JoinColumn(name="cropId")
    private Crop crop;
   
    public Request()
    {
    }

    public Request(Long requestId, int quantity, String status, LocalDate requestDate, String rejectionReason,
            AgroChemical agroChemical, User user, Crop crop) {
        this.requestId = requestId;
        this.quantity = quantity;
        this.status = status;
        this.requestDate = requestDate;
        this.rejectionReason = rejectionReason;
        this.agroChemical = agroChemical;
        this.user = user;
        this.crop = crop;
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    public AgroChemical getAgroChemical() {
        return agroChemical;
    }

    public void setAgroChemical(AgroChemical agroChemical) {
        this.agroChemical = agroChemical;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    
  

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    @Override
    public String toString() {
        return "Request [requestId=" + requestId + ", quantity=" + quantity + ", status=" + status + ", requestDate="
                + requestDate + ", rejectionReason=" + rejectionReason + ", agroChemical=" + agroChemical + ", user="
                + user + ", crop=" + crop + "]";
    }

    

    
}
