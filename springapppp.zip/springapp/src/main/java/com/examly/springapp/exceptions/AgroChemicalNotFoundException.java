package com.examly.springapp.exceptions;

public class AgroChemicalNotFoundException  extends RuntimeException {
      
    public AgroChemicalNotFoundException(){

    }

    public AgroChemicalNotFoundException(String msg){
       super(msg);
    }
}
