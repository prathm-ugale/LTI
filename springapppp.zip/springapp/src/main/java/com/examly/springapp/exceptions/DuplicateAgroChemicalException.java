package com.examly.springapp.exceptions;

public class DuplicateAgroChemicalException extends RuntimeException{

    public DuplicateAgroChemicalException(){

    }

    public DuplicateAgroChemicalException(String msg){
        super(msg);
    }
    
}
