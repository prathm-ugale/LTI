package com.examly.springapp.model;
 
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
 
@Entity

public class AgroChemical {
   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long agroChemicalId;
    private String name;
    private String brand;
    private String category;
    private String description;
    private String unit;
    private double pricePerUnit;
    private int quantity;
    private String image;
   
    @OneToMany( mappedBy="agroChemical",cascade = CascadeType.ALL)
    private List<Request> request;
   
 
    public AgroChemical() {
    }
 
 
    public AgroChemical(Long agroChemicalId, String name, String brand, String category, String description,
            String unit, double pricePerUnit, int quantity, String image) {
        this.agroChemicalId = agroChemicalId;
        this.name = name;
        this.brand = brand;
        this.category = category;
        this.description = description;
        this.unit = unit;
        this.pricePerUnit = pricePerUnit;
        this.quantity = quantity;
        this.image = image;
    }
 
 
    public Long getAgroChemicalId() {
        return agroChemicalId;
    }
 
    public void setAgroChemicalId(Long agroChemicalId) {
        this.agroChemicalId = agroChemicalId;
    }
 
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getBrand() {
        return brand;
    }
 
    public void setBrand(String brand) {
        this.brand = brand;
    }
 
    public String getCategory() {
        return category;
    }
 
    public void setCategory(String category) {
        this.category = category;
    }
 
    public String getDescription() {
        return description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }
 
    public String getUnit() {
        return unit;
    }
 
    public void setUnit(String unit) {
        this.unit = unit;
    }
 
    public double getPricePerUnit() {
        return pricePerUnit;
    }
 
    public void setPricePerUnit(double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }
 
    public int getQuantity() {
        return quantity;
    }
 
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
 
    public String getImage() {
        return image;
    }
 
    public void setImage(String image) {
        this.image = image;
    }


    @Override
    public String toString() {
        return "AgroChemical [agroChemicalId=" + agroChemicalId + ", name=" + name + ", brand=" + brand + ", category="
                + category + ", description=" + description + ", unit=" + unit + ", pricePerUnit=" + pricePerUnit
                + ", quantity=" + quantity + ", image=" + image + ", request=" + request + "]";
    }
  
}