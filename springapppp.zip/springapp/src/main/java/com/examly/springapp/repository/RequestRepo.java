package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.examly.springapp.model.User;
import com.examly.springapp.model.AgroChemical;
import com.examly.springapp.model.Crop;
import com.examly.springapp.model.Request;

@Repository

public interface RequestRepo extends JpaRepository<Request,Long>
 {
     public List<Request> findByUser(User user);
     public Request findByCrop(Crop crop);
     public Request findByAgroChemical(AgroChemical agroChemical);
}
