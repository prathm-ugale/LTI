package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import com.examly.springapp.exceptions.AgroChemicalNotFoundException;
import com.examly.springapp.exceptions.CropNotFoundException;
import com.examly.springapp.exceptions.RequestNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.AgroChemical;
import com.examly.springapp.model.Crop;
import com.examly.springapp.model.Request;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.AgroChemicalRepo;
import com.examly.springapp.repository.CropRepo;
import com.examly.springapp.repository.RequestRepo;
import com.examly.springapp.repository.UserRepo;
import jakarta.persistence.EntityNotFoundException;


@Service

public class RequestServiceImpl implements RequestService{

    @Autowired
    RequestRepo requestRepo;

    @Autowired
    UserRepo userRepo;

    @Autowired
    CropRepo cropRepo;
    
    @Autowired
    AgroChemicalRepo agroChemicalRepo;

    @Autowired
    AgroChemicalServiceImpl agroChemicalServiceImpl;

    HashMap<Long,Integer> map=new HashMap<>();

    public Request createRequest(Request request)
    {
        AgroChemical agrochemical = agroChemicalRepo.findById(request.getAgroChemical().getAgroChemicalId()).orElse(null);
        request.setAgroChemical(agrochemical);
        Crop crop = cropRepo.findById(request.getCrop().getCropId()).orElse(null);
        request.setCrop(crop);
        User user = userRepo.findById(request.getUser().getUserId()).orElse(null);
        request.setUser(user);
        if(agrochemical.getQuantity()<request.getQuantity()){
            throw new EntityNotFoundException("No available quantity");
        }
        agrochemical.setQuantity(agrochemical.getQuantity()-request.getQuantity());
        agroChemicalServiceImpl.updateAgroChemical(agrochemical.getAgroChemicalId(),agrochemical);
       return requestRepo.save(request);
    
    }

    public List<Request> getAllRequests()
    {
        List<Request> requests=requestRepo.findAll();
        return requests;
    }

    public Request updateRequest(Long id,Request request)
    {
        Optional<Request> opt=requestRepo.findById(id);
        if(opt.isEmpty())
        {
             throw new RequestNotFoundException("Request is not found");
        }
        Request r = opt.get();
        r.setQuantity(request.getQuantity());
        r.setRequestDate(request.getRequestDate());
        r.setStatus(request.getStatus());
        if(request.getStatus().equals("Approved") ){
           if(map.containsKey(request.getRequestId())){
              int getQ=request.getAgroChemical().getQuantity()-request.getQuantity();
              AgroChemical getAgroChemical=request.getAgroChemical();
              getAgroChemical.setQuantity(getQ);
              agroChemicalServiceImpl.updateAgroChemical(r.getAgroChemical().getAgroChemicalId(),getAgroChemical);
           }
           else{
            map.put(request.getRequestId(),1);
           }
        }
        
        int setQ=request.getAgroChemical().getQuantity()+request.getQuantity();
        AgroChemical setAgroChemical=request.getAgroChemical();
        setAgroChemical.setQuantity(setQ);
        if(request.getStatus().equals("Rejected")){
            map.put(request.getRequestId(),1);
            agroChemicalServiceImpl.updateAgroChemical(r.getAgroChemical().getAgroChemicalId(),setAgroChemical);
        }
        
        return requestRepo.save(r);
    }

    public Request deleteRequest(Long id)
    {
        Optional<Request> opt=requestRepo.findById(id);
        if(opt.isEmpty())
        {
            throw new RequestNotFoundException("Request is not found");
        }
        AgroChemical setChemical=opt.get().getAgroChemical();
        setChemical.setQuantity(setChemical.getQuantity()+opt.get().getQuantity());
        agroChemicalServiceImpl.updateAgroChemical(setChemical.getAgroChemicalId(), setChemical);
        
        requestRepo.deleteById(id);
        return opt.get();
    }

    public Request getRequestById(Long id) 
    {
       Optional<Request> opt=requestRepo.findById(id);
       if(opt.isEmpty())
       throw new RequestNotFoundException("Request is not found"); 
       return opt.get();
    }

    
    public List<Request> getRequestUserById(int userId)
     {
        Optional<User> u=userRepo.findById(userId);
        if(u.isEmpty())
        {
            throw new UserNotFoundException("User not found");
        }
        return requestRepo.findByUser(u.get());

     }

     public Request getRequestCropById(Long cropId)
     {
        Optional<Crop> u=cropRepo.findById(cropId);
        if(u.isEmpty())
        {
            throw new CropNotFoundException("Crop not found");
        }
        return requestRepo.findByCrop(u.get());

     }

     public Request getRequestAgroChemicalById(Long agroChemicalId)
     {
        Optional<AgroChemical> u=agroChemicalRepo.findById(agroChemicalId);
        if(u.isEmpty())
        {
            throw new AgroChemicalNotFoundException("Crop not found");
        }
        return requestRepo.findByAgroChemical(u.get());

     }


}
