package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.exceptions.AgroChemicalNotFoundException;
import com.examly.springapp.exceptions.CropNotFoundException;
import com.examly.springapp.exceptions.RequestNotFoundException;
import com.examly.springapp.model.Request;
import com.examly.springapp.service.RequestServiceImpl;

import jakarta.persistence.EntityNotFoundException;

@RestController

@CrossOrigin

public class RequestController {

    @Autowired
    
    RequestServiceImpl requestServiceImpl;

    @PostMapping("/api/request")
    public ResponseEntity<?> createRequest(@RequestBody Request request)
    {
        try{
        return ResponseEntity.status(201).body(requestServiceImpl.createRequest(request));
        }catch(EntityNotFoundException e){
            return ResponseEntity.status(500).body("No available quantity");
        }
        
    }

    @GetMapping("/api/request/{id}")
    public ResponseEntity<?> getRequestById(@PathVariable Long id)
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.getRequestById(id));
        }catch(RequestNotFoundException e)
        {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/request")
    public ResponseEntity<?> getAllRequests()
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.getAllRequests());
        }catch(Exception e)
        {
            return ResponseEntity.status(500).body("Internal Server Issues");
        }
           
    }

    @PutMapping("/api/request/{id}")
    public ResponseEntity<?> updateRequest(@PathVariable Long id,@RequestBody Request request)
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.updateRequest(id,request));   
        }catch(RequestNotFoundException e)
        {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @DeleteMapping("/api/request/{id}")
    public ResponseEntity<?> deleteRequest(@PathVariable Long id)
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.deleteRequest(id));
        }catch(RequestNotFoundException e)
        {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/request/user/{userId}")
    public ResponseEntity<?>  getRequestUserById(@PathVariable int userId)
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.getRequestUserById(userId));
        }catch(UserNotFoundException e)
        {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/request/crop/{cropId}")
    public ResponseEntity<?>  getRequestCropById(@PathVariable Long cropId)
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.getRequestCropById(cropId));
        }catch(CropNotFoundException e)
        {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping("/api/request/agroChemical/{agroChemicalId}")
    public ResponseEntity<?>  getRequestAgroChemicalById(@PathVariable Long agroChemicalId)
    {
        try
        {
            return ResponseEntity.status(200).body(requestServiceImpl.getRequestAgroChemicalById(agroChemicalId));
        }catch(AgroChemicalNotFoundException e)
        {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

}
