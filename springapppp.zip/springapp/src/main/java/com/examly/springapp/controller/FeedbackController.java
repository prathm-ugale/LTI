package com.examly.springapp.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.examly.springapp.exceptions.FeedbackNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.service.FeedbackService;
 
@RestController

@CrossOrigin

@RequestMapping("/api/feedback")

public class FeedbackController {
 
    @Autowired
    
    private FeedbackService feedbackService;
 
    @PostMapping
    public ResponseEntity<?> addFeedback(@RequestBody Feedback feedback) {
        try {
            return ResponseEntity.status(201).body(feedbackService.addFeedback(feedback));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Feedback not added.");
        }
    }
 
    @GetMapping
    public ResponseEntity<?> viewFeedback() {
        try {
            return ResponseEntity.status(200).body(feedbackService.viewFeedback());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Feedback Not Found!");
        }
    }
 
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserFeedback(@PathVariable Integer userId) {
        try {
            return ResponseEntity.status(200).body(feedbackService.getFeedbackByUserId(userId));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Feedback Not Found!");
        }
    }
 
    @DeleteMapping("/{feedbackId}")
    public ResponseEntity<?> deleteFeedback(@PathVariable int feedbackId) {
        try {
            feedbackService.deleteFeedback(feedbackId);
            return ResponseEntity.status(200).body(true);
        } catch (FeedbackNotFoundException e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }
}