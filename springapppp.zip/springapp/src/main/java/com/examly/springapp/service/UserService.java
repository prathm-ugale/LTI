package com.examly.springapp.service;

import com.examly.springapp.model.AuthUser;
import com.examly.springapp.model.User;

public interface UserService {
    
    public User add(User user)throws Exception;
    public AuthUser loginUser(User user) throws Exception;

    public User getUserById(int userId);
   


}
