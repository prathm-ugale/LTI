package com.examly.springapp.exceptions;

public class CropNotFoundException extends RuntimeException{

    public CropNotFoundException(){

    }
    public CropNotFoundException(String message){
        super(message);
    }
    
}
