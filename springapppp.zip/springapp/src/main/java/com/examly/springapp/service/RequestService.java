package com.examly.springapp.service;

import com.examly.springapp.model.Request;
import java.util.*;


public interface RequestService {

    public Request createRequest(Request request);
    public List<Request> getAllRequests();
    public Request updateRequest(Long id,Request request);
    public Request deleteRequest(Long id);
    public Request getRequestById(Long id);
    public List<Request> getRequestUserById(int userId);
}
