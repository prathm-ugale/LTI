package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.model.AgroChemical;

public interface AgroChemicalService {
    
    AgroChemical addAgroChemical(AgroChemical agroChemical);
    AgroChemical getAgroChemicalById(long id);
    List<AgroChemical> getAllAgroChemicals();
    AgroChemical updateAgroChemical(long id, AgroChemical agroChemical);
    void deleteAgroChemicl(long id);

}
