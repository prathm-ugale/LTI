package com.examly.springapp.model;
 
import java.time.LocalDate;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
 
@Entity

public class Feedback {
   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int feedbackId;
    private String feedbackText;
    private LocalDate date;
    private int rating;
   
    @ManyToOne
    @JoinColumn(name="userId")
    private User user;
    @ManyToOne
    private AgroChemical agroChemical;
 
    public Feedback() {
    }
 
    public Feedback(int feedbackId, String feedbackText, LocalDate date, User user, int rating,AgroChemical agroChemical) {
        this.feedbackId = feedbackId;
        this.feedbackText = feedbackText;
        this.date = date;
        this.user = user;
        this.rating = rating;
        this.agroChemical=agroChemical;
    }
 
    
    public int getFeedbackId() {
        return feedbackId;
    }
 
    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }
 
    public String getFeedbackText() {
        return feedbackText;
    }
 
    public void setFeedbackText(String feedbackText) {
        this.feedbackText = feedbackText;
    }
 
    public LocalDate getDate() {
        return date;
    }
 
    public void setDate(LocalDate date) {
        this.date = date;
    }
 
    public User getUser() {
        return user;
    }
 
    public void setUser(User user) {
        this.user = user;
    }
 
    public int getRating() {
        return rating;
    }
 
    public void setRating(int rating) {
        this.rating = rating;
    }
 
    public AgroChemical getAgrochemical() {
        return agroChemical;
    }

    public void setAgrochemical(AgroChemical agrochemical) {
        this.agroChemical = agrochemical;
    }

    @Override
    public String toString() {
        return "Feedback [feedbackId=" + feedbackId + ", feedbackText=" + feedbackText + ", date=" + date + ", rating="
                + rating + ", user=" + user + ", agroChemical=" + agroChemical + "]";
    }

    
}