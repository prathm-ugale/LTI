package com.examly.springapp.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.examly.springapp.exceptions.AgroChemicalNotFoundException;
import com.examly.springapp.exceptions.DuplicateAgroChemicalException;
import com.examly.springapp.model.AgroChemical;
import com.examly.springapp.service.AgroChemicalServiceImpl;


@RestController

@CrossOrigin

public class AgroChemicalController {


    private static final String UPLOAD_DIR = "/home/coder/project/workspace/angularapp/src/assets/image/";
   
    @Autowired

    private AgroChemicalServiceImpl agroChemicalServiceImpl;


    @PostMapping("/api/agrochemical")
    public ResponseEntity<?> addAgroChemical(@RequestBody AgroChemical agroChemical){
    try{
        AgroChemical savedAgroChemical = agroChemicalServiceImpl.addAgroChemical(agroChemical);
        return  ResponseEntity.status(201).body(savedAgroChemical); 
     }
     catch(DuplicateAgroChemicalException e){
        return ResponseEntity.status(500).body(e.getMessage());
       }
    
    }


    @GetMapping("/api/agrochemical/{id}")
    public ResponseEntity<?> getAgroChemicalById(@PathVariable Long id){
       
           AgroChemical getAgroChemical = agroChemicalServiceImpl.getAgroChemicalById(id);
           return ResponseEntity.status(200).body(getAgroChemical);
       
    }


    @GetMapping("/api/agrochemical")
    public ResponseEntity<?> getAllAgroChemicals(){
        try {
            List<AgroChemical> agroChemicalsList = agroChemicalServiceImpl.getAllAgroChemicals();
            return ResponseEntity.status(200).body(agroChemicalsList);
        } catch (Exception e) {
           return ResponseEntity.status(500).body(e.getMessage());
        }
    }


    @PutMapping("/api/agrochemical/{id}")
    public ResponseEntity<?> updateAgroChemical(@PathVariable Long id,@RequestBody AgroChemical agroChemical){
        try{
          AgroChemical updatedAgroChemical=agroChemicalServiceImpl.updateAgroChemical(id, agroChemical);
          return ResponseEntity.status(200).body(updatedAgroChemical);
        }catch(AgroChemicalNotFoundException e){
          return ResponseEntity.status(500).body(e.getMessage()); 
        }
    }
    

    @DeleteMapping("/api/agrochemical/{id}")
    public ResponseEntity<?> deleteAgroChemical(@PathVariable Long id){
        try {
           agroChemicalServiceImpl.deleteAgroChemicl(id);
           return ResponseEntity.status(200).body(true); 
        } catch (AgroChemicalNotFoundException e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @PostMapping("api/agrochemical/upload/{agroChemicalId}")
    public ResponseEntity<?> uploadImage(@RequestParam("file") MultipartFile file,@PathVariable long agroChemicalId){
        System.out.println("Request recevied");
        System.out.println(file);
        if(file.isEmpty()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("File is empty");
        }
        try{
            Path path = Paths.get(UPLOAD_DIR+"agrochemical"+agroChemicalId+".jpeg");
            
            Files.createDirectories(path.getParent());
            Files.write(path,file.getBytes());
            System.out.println("uploaded");
            return ResponseEntity.ok(agroChemicalServiceImpl.getAgroChemicalById(agroChemicalId));
        }catch(IOException e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error uploading file");
        }
    }

}
