import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Crop } from '../models/crop.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CropService {

  apiUrl:string="https://ide-fbfefdbcaafbaedabccffcdffebeafdebbecb.premiumproject.examly.io/proxy/8080/api/crop"
 
  constructor(private httpClient:HttpClient) { }

  addCrop(requestObject:Crop):Observable<Crop>{
    return this.httpClient.post(this.apiUrl,requestObject) as Observable<Crop>
  }

  getCropByUserId(id:number):Observable<Crop[]>{
    return this.httpClient.get(this.apiUrl+"/user"+"/"+id) as Observable<Crop[]>
  }

  getCropById(id:number):Observable<Crop>{
    return this.httpClient.get(this.apiUrl+"/"+id) as Observable<Crop>
  }

  getAllCrops():Observable<Crop[]>{
    return this.httpClient.get(this.apiUrl) as Observable<Crop[]>
  }

  deleteCrop(cropId:number):Observable<any>{
    return this.httpClient.delete(this.apiUrl+"/"+cropId) as Observable<any>
  }

  updateCrop(id:number,requestObject:Crop):Observable<any>{
    return this.httpClient.put(this.apiUrl+"/"+id,requestObject) as Observable<any>
  }
}
