
 
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback.model';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
 
  apiUrl: string = "https://ide-fbfefdbcaafbaedabccffcdffebeafdebbecb.premiumproject.examly.io/proxy/8080/api/feedback";

  constructor(private httpClient: HttpClient) { }
 
  public sendFeedback(feedback: Feedback): Observable<any>{
    return this.httpClient.post<any>(this.apiUrl, feedback);
  }
 
  
  public getAllFeedbacksByUserId(userId: number): Observable<Feedback[]>{
    return this.httpClient.get<Feedback[]>(this.apiUrl+'/user'+'/'+userId);
  }
 
  
  public deleteFeedback(feedbackId: number):Observable<any>{
    return this.httpClient.delete<any>(this.apiUrl+'/'+feedbackId);
  }
 
  
  public getFeedbacks():Observable<Feedback[]>{
    return this.httpClient.get<Feedback[]>(this.apiUrl);
  }
 
 
}
 