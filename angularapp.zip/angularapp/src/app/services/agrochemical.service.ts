import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AgroChemical } from '../models/agrochemical.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgrochemicalService {

  constructor(private httpClient:HttpClient) { }
  

   apiUrl:string="https://ide-fbfefdbcaafbaedabccffcdffebeafdebbecb.premiumproject.examly.io/proxy/8080/api/agrochemical";
   
   
   createAgroChemical(formData: FormData): Observable<any> {
    return this.httpClient.post(`${this.apiUrl}/create`, formData);
  }
   public addAgroChemical(chemicalForm : FormData) :Observable<AgroChemical> {
     return this.httpClient.post<AgroChemical>(this.apiUrl,chemicalForm);
   }

   public getAgroChemical(id:number) : Observable<AgroChemical> {
     return this.httpClient.get<AgroChemical>(this.apiUrl+"/"+id)
   }

   public getAllAgroChemicals() :Observable<AgroChemical[]>{
     return this.httpClient.get<AgroChemical[]>(this.apiUrl)
   }

   public deleteAgroChemical(agroChemicalId:number) : Observable<any>{
    console.log("Agrochemicaluuu id",agroChemicalId);
    
     return this.httpClient.delete(this.apiUrl+"/"+agroChemicalId);
   }

   public updateAgroChemical(id:number,agroChemical:AgroChemical) : Observable<AgroChemical>{
      return this.httpClient.put<AgroChemical>(this.apiUrl+"/"+id,agroChemical);
   }
   
   uploadImage(agroChemicalId : number,file:File):Observable<any>{
    const formData:FormData = new FormData();
    formData.append('file',file);
    return this.httpClient.post(this.apiUrl+"/upload/"+agroChemicalId,formData);
}

}
