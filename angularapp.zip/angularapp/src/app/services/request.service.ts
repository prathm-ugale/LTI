import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Request } from '../models/request.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RequestService {

  public apiUrl:string="https://ide-fbfefdbcaafbaedabccffcdffebeafdebbecb.premiumproject.examly.io/proxy/8080/api/request";

  constructor(private httpClient:HttpClient) { }

  public addRequest(request:Request):Observable<Request>
  {
    console.log(request);
    return this.httpClient.post(this.apiUrl,request)as Observable<Request>;
    
  }

  public getAllRequest():Observable<Request[]>
  {
    return this.httpClient.get(this.apiUrl) as Observable<Request[]>
  }

  public updateRequestStatus(requestId:number,request:Request):Observable<Request>
  {
    return this.httpClient.put(this.apiUrl+"/"+requestId,request) as Observable<Request>;
  }

  public deleteRequest(requestId:number):Observable<any>
  {
    return this.httpClient.delete(this.apiUrl+"/"+requestId);
  }

  public getRequestsByUserId(userId:number):Observable<Request[]>
  {
    return this.httpClient.get(this.apiUrl+"/user/"+userId) as Observable<Request[]>;
  }
  public getRequestsByCropId(cropId:number):Observable<Request[]>
  {
    return this.httpClient.get(this.apiUrl+"/crop/"+cropId) as Observable<Request[]>;
  }

  public getRequestsByAgroChemicalId(agroChemicalId:number):Observable<Request[]>
  {
    return this.httpClient.get(this.apiUrl+"/agroChemical/"+agroChemicalId) as Observable<Request[]>;
  }

  public getRequestById(requestId:number):Observable<Request>
  {
    return this.httpClient.get(this.apiUrl+"/"+requestId) as Observable<Request>
  }
}
