import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';
import { tap } from 'rxjs/operators';
import { Login } from '../models/login.model';
import { UserStoreService } from '../helpers/user-store.service';
import { API_URL } from '../contant';
import { AuthUser } from '../models/auth-user';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  baseUrl:string="https://ide-fbfefdbcaafbaedabccffcdffebeafdebbecb.premiumproject.examly.io/proxy/8080/api";

  constructor(private http:HttpClient,private userStore:UserStoreService) {
   }

  register(user:User):Observable<User>{
    return this.http.post<User>(this.baseUrl+"/register",user).pipe(
      tap(registeredUser=>{
        console.log("User registered successfully",registeredUser);
      })
    );
  }
  login(credentials:Login):Observable<User>{
    return this.http.post<User>(this.baseUrl+"/login",credentials);
  }
  logout():void{
    this.userStore.setUser(null);
    }

  isAuthenticated():boolean{
    return this.userStore.isLoggedIn();
    }
  isAdmin():boolean{
    const authUser=this.userStore.authUser;
    console.log(authUser.role);
    return authUser.role === 'SELLER';
    }
  getCurrentUserId():number | null{
    const authUser=this.userStore.authUser;
    return authUser ? authUser.userId:null;
    
  }

  getCustomerName():string | null{
    const authUser=this.userStore.authUser;
    return authUser?.email;
  }

  public getUserById(id: number):Observable<User>{
    return this.http.get<User>(this.baseUrl+"/user"+"/"+id);
  }


}
 


  