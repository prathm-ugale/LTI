import { AbstractControl, ValidatorFn } from '@angular/forms';

export function noFutureDateValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const selectedDate = new Date(control.value);
    const today = new Date();
    return selectedDate > today ? { 'noFutureDate': { value: control.value } } : null;
  };
}
