import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorComponent } from './components/error/error.component';
import { FarmeraddcropComponent } from './components/farmeraddcrop/farmeraddcrop.component';
import { FarmeraddfeedbackComponent } from './components/farmeraddfeedback/farmeraddfeedback.component';
import { FarmereditcropComponent } from './components/farmereditcrop/farmereditcrop.component';
import { FarmermyrequestComponent } from './components/farmermyrequest/farmermyrequest.component';
import { FarmernavComponent } from './components/farmernav/farmernav.component';
import { FarmerviewchemicalComponent } from './components/farmerviewchemical/farmerviewchemical.component';
import { FarmerviewcropComponent } from './components/farmerviewcrop/farmerviewcrop.component';
import { FarmerviewfeedbackComponent } from './components/farmerviewfeedback/farmerviewfeedback.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { SelleraddchemicalComponent } from './components/selleraddchemical/selleraddchemical.component';
import { SellereditchemicalComponent } from './components/sellereditchemical/sellereditchemical.component';
import { SellernavComponent } from './components/sellernav/sellernav.component';
import { SellerviewchemicalComponent } from './components/sellerviewchemical/sellerviewchemical.component';
import { SellerviewfeedbackComponent } from './components/sellerviewfeedback/sellerviewfeedback.component';
import { SellerviewrequestsComponent } from './components/sellerviewrequests/sellerviewrequests.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
 
 
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
}


@NgModule({
  declarations: [
    AppComponent,
    ErrorComponent,
    FarmeraddcropComponent,
    FarmeraddfeedbackComponent,
    FarmereditcropComponent,
    FarmermyrequestComponent,
    FarmernavComponent,
    FarmerviewchemicalComponent,
    FarmerviewcropComponent,
    FarmerviewfeedbackComponent,
    HomeComponent,
    LoginComponent,
    NavbarComponent,
    RegistrationComponent,
    SelleraddchemicalComponent,
    SellereditchemicalComponent,
    SellernavComponent,
    SellerviewchemicalComponent,
    SellerviewfeedbackComponent,
    SellerviewrequestsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    BrowserModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
