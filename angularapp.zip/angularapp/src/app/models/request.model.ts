import { AgroChemical } from "./agrochemical.model";
import { Crop } from "./crop.model";
import { User } from "./user.model";
 
export class Request {
 
 requestId?: number;
 agroChemical?: AgroChemical;
 user?: User;
 crop?: Crop;
 quantity?: number;
 status?: string;
 requestDate?: Date;  
 ind?:boolean;
  feedbackDisabled?: boolean;
  rejectionReason?: string;
 }
   
   