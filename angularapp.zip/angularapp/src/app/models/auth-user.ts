export interface AuthUser {
    
        userId?:number;
        email?:string;
        userName?:string;
        jwtToken?:string;
        role?:string;
    
    
}
