export class AgroChemical { 
    agroChemicalId?: number; 
    name?: string; 
    brand?: string; 
    category?: string; 
    description?: string; 
    unit?: string; 
    pricePerUnit?: number; 
    coverImage?: string; 
    quantity?:number;
   } 
