import { AgroChemical } from './agrochemical.model';
import { User } from './user.model';

export class Feedback {
  feedbackId?: number;
  feedbackText: string;
  date: string; 
  user: User;
  rating: number;
  agroChemical?:AgroChemical;

  constructor(feedbackId: number, feedbackText: string, date: string, user: User, rating: number) {
    this.feedbackText = feedbackText;
    this.date = date;
    this.user = user;
    this.rating = rating;
  }
}