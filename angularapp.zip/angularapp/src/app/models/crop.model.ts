import { User } from "./user.model";

export class Crop { 

    cropId?: number; 
    cropName?: string; 
    cropType?: string; 
    description?: string; 
    plantingDate?: string; 
    user?: User; 
    
   } 