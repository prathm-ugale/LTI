export const API_URL:string="https://ide-fbfefdbcaafbaedabccffcdffebeafdebbecb.premiumproject.examly.io/proxy/8080";
