import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { ErrorComponent } from './components/error/error.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FarmernavComponent } from './components/farmernav/farmernav.component';
import { SellernavComponent } from './components/sellernav/sellernav.component';
import { FarmeraddcropComponent } from './components/farmeraddcrop/farmeraddcrop.component';
import { FarmeraddfeedbackComponent } from './components/farmeraddfeedback/farmeraddfeedback.component';
import { FarmereditcropComponent } from './components/farmereditcrop/farmereditcrop.component';
import { FarmermyrequestComponent } from './components/farmermyrequest/farmermyrequest.component';
import { FarmerviewchemicalComponent } from './components/farmerviewchemical/farmerviewchemical.component';
import { FarmerviewcropComponent } from './components/farmerviewcrop/farmerviewcrop.component';
import { FarmerviewfeedbackComponent } from './components/farmerviewfeedback/farmerviewfeedback.component';
import { SelleraddchemicalComponent } from './components/selleraddchemical/selleraddchemical.component';
import { SellereditchemicalComponent } from './components/sellereditchemical/sellereditchemical.component';
import { SellerviewchemicalComponent } from './components/sellerviewchemical/sellerviewchemical.component';
import { SellerviewrequestsComponent } from './components/sellerviewrequests/sellerviewrequests.component';
import { SellerviewfeedbackComponent } from './components/sellerviewfeedback/sellerviewfeedback.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'',component:HomeComponent},
  {path:'error',component:ErrorComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegistrationComponent},
  {path:'navbar',component:NavbarComponent},
  {path:'farmernav',component:FarmernavComponent},
  {path:'sellernav',component:SellernavComponent},
  {path:'farmer/add/crop',component:FarmeraddcropComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }
  },
  {path:'farmer/add/feedback',component:FarmeraddfeedbackComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }
  },
  {path:'farmer/edit/crop/:id',component:FarmereditcropComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }
  },
  {path:'farmer/myRequest',component:FarmermyrequestComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }},
  {path:'farmer/myRequest/:agroChemicalId/:cropId/:quantity',component:FarmermyrequestComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }},
  {path:'farmer/myRequest',component:FarmermyrequestComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }},
  {path:'farmer/view/chemical',component:FarmerviewchemicalComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }},
  {path:'farmer/view/crop',component:FarmerviewcropComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }},
  {path:'farmer/view/feedback/:userId',component:FarmerviewfeedbackComponent,canActivate: [AuthGuard],
  data: { role: 'FARMER' }},
  {path:'seller/add/chemical',component:SelleraddchemicalComponent,canActivate: [AuthGuard],
  data: { role: 'SELLER' }},
  {path:'seller/edit/chemical/:id',component:SellereditchemicalComponent,canActivate: [AuthGuard],
  data: { role: 'SELLER' }},
  {path:'seller/view/chemical',component:SellerviewchemicalComponent,canActivate: [AuthGuard],
  data: { role: 'SELLER' }},
  {path:'seller/view/requests',component:SellerviewrequestsComponent,canActivate: [AuthGuard],
  data: { role: 'SELLER' }},
  {path:'seller/view/feedback',component:SellerviewfeedbackComponent,canActivate: [AuthGuard],
  data: { role: 'SELLER' }}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

