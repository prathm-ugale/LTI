import { Component, OnInit } from '@angular/core';
import { AgroChemical } from 'src/app/models/agrochemical.model';
import { AgrochemicalService } from 'src/app/services/agrochemical.service';
import Swal from 'sweetalert2';

@Component({
    selector: 'app-sellerviewchemical',
    templateUrl: './sellerviewchemical.component.html',
    styleUrls: ['./sellerviewchemical.component.css']
})
export class SellerviewchemicalComponent implements OnInit {

    chemicals: AgroChemical[] = [];
    deleteId: number = 0;
    showData = false;
    selectedChemical: AgroChemical;

    constructor(private agroChemicalService: AgrochemicalService) { }

    ngOnInit(): void {
        this.getAllAgroChemicals();
    }

    getAllAgroChemicals() {
        this.agroChemicalService.getAllAgroChemicals().subscribe(data => {
            this.chemicals = data;
        });
    }

    filter(findData: string) {
        this.agroChemicalService.getAllAgroChemicals().subscribe(data => {
            this.chemicals = data.filter(b =>
                b.name.toLowerCase().includes(findData.toLowerCase()) ||
                b.brand.toLowerCase().includes(findData.toLowerCase()) ||
                b.category.toLowerCase().includes(findData.toLowerCase())
            );
        });
    }

    showModal(id: number) {
        this.deleteId = id;
        Swal.fire({
            title: 'Are you sure?',
            text: 'You won\'t be able to revert this!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.confirmDelete();
            }
        });
    }

    confirmDelete() {
        this.agroChemicalService.deleteAgroChemical(this.deleteId).subscribe(() => {
            this.getAllAgroChemicals();
            Swal.fire({
                title: 'Deleted!',
                text: 'The agrochemical has been deleted successfully.',
                icon: 'success',
                confirmButtonColor: '#90a955'
            });
        });
    }

    showMore(agroChemical: AgroChemical): void {
        this.selectedChemical = agroChemical;
        this.showData = true;
    }

    closeModal() {
        this.showData = false;
    }
}
