import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-farmeraddfeedback',
  templateUrl: './farmeraddfeedback.component.html',
  styleUrls: ['./farmeraddfeedback.component.css']
})
export class FarmeraddfeedbackComponent implements OnInit {

  feedbackForm: FormGroup;
  id: number;
  feedbackObj: Feedback = { user: null, feedbackText: '', date: '', rating: 0 };
  rating: number = 0;
  hoverState: number = 0;  
  stars: Array<number> = [1, 2, 3, 4, 5];  

  constructor(
    private feedbackService: FeedbackService,
    private formBuilder: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.feedbackForm = this.formBuilder.group({
      feedbackText: ['', [Validators.required]]
    });

    this.activatedRoute.paramMap.subscribe(data => {  
      this.id = parseInt(data.get('userId'));
    });
  }

  public get feedback() {
    return this.feedbackForm.get('feedbackText');
  }

  ngOnInit(): void {}

  
  public rate(star: number) {
    this.rating = star;  
  }

  
  public hover(star: number) {
    this.hoverState = star; 
  }

  
  public clearHover() {
    this.hoverState = 0;  
  }

  
  public addFeedbackForm() {
    if (this.feedbackForm.valid) {
      const userfromLocalStorage = localStorage.getItem('authUser');
      const userObject = JSON.parse(userfromLocalStorage);

      const userIdfromLocal = parseInt(userObject.userId);
      const username = localStorage.getItem('userName');

      const user = new User(userIdfromLocal, '', '', username, '', '');
      const newFeedback = new Feedback(
        0,
        this.feedbackForm.value.feedbackText,
        new Date().toISOString().split('T')[0],
        user,
        this.rating 
      );

      this.feedbackService.sendFeedback(newFeedback).subscribe(data => {
        console.log(data);
        this.feedbackForm.reset();
        console.log('Feedback sent successfully.');
      
        Swal.fire({
          title: 'Feedback Submitted!',
          text: 'Thank you for your valuable feedback!',
          icon: 'success',
          confirmButtonColor: '#90a955',
        }).then(() => {
          this.router.navigate(['/farmer/view/feedback', userIdfromLocal]);
        });
      });
      
    }
  }
}