import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AgroChemical } from 'src/app/models/agrochemical.model';
import { AgrochemicalService } from 'src/app/services/agrochemical.service';

@Component({
    selector: 'app-selleraddchemical',
    templateUrl: './selleraddchemical.component.html',
    styleUrls: ['./selleraddchemical.component.css']
})
export class SelleraddchemicalComponent implements OnInit {

    agroChemicalForm: FormGroup;
    selectedFile: File | null = null;

    constructor(
        private formBuilder: FormBuilder,
        private agroChemicalService: AgrochemicalService,
        private router: Router
    ) {
        this.agroChemicalForm = this.formBuilder.group({
            name: ['', Validators.required],
            brand: ['', Validators.required],
            category: ['', Validators.required],
            description: ['', Validators.required],
            unit: ['', Validators.required],
            pricePerUnit: ['', [Validators.required , Validators.min(1)]],
            coverImage: ['', Validators.required],
            quantity:['',[Validators.required,Validators.min(0)]]
        });
    }

    ngOnInit(): void {}

    onFileChange(event: any) {
        this.selectedFile = event.target.files[0];
    }

    onSubmit() {
        if (this.agroChemicalForm.valid) {
            const agroChemicalData = this.agroChemicalForm.value;
            this.agroChemicalService.addAgroChemical(agroChemicalData).subscribe(


                (response: any) => {
                         
                    if (this.selectedFile) {
                        this.agroChemicalService.uploadImage(response.agroChemicalId, this.selectedFile).subscribe(
                          
                            (uploadResponse: any) => {
                                console.log('File uploaded successfully', uploadResponse);
                                alert("Chemical added successfully!");
                                this.router.navigate(['/seller/view/chemical']);
                            },
                            (error: any) => {
                                console.error('Error uploading file', error);
                            }
                        );
                    }
                },
                (error: any) => {
                    console.error('Error adding agrochemical', error);
                }
            );
        }
    }

    

  public get name(){
    return this.agroChemicalForm.get('name');
  }

  public get brand(){
    return this.agroChemicalForm.get('brand');
  }

  public get category(){
    return this.agroChemicalForm.get('category');
  }

  public get description(){
    return this.agroChemicalForm.get('description');
  }

  public get unit(){
    return this.agroChemicalForm.get('unit');
  }

  public get pricePerUnit(){
    return this.agroChemicalForm.get('pricePerUnit');
  }

  public get quantity(){
    return this.agroChemicalForm.get('quantity');
  }

  public get image(){
    return this.agroChemicalForm.get('image');
  }

    public get f() {
        return this.agroChemicalForm.controls;
    }
}