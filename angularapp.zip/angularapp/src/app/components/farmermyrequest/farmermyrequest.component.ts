import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Request } from 'src/app/models/request.model';
import { AgrochemicalService } from 'src/app/services/agrochemical.service';
import { AuthService } from 'src/app/services/auth.service';
import { CropService } from 'src/app/services/crop.service';
import { RequestService } from 'src/app/services/request.service';
import Swal from 'sweetalert2';
 
@Component({
  selector: 'app-farmermyrequest',
  templateUrl: './farmermyrequest.component.html',
  styleUrls: ['./farmermyrequest.component.css']
})
 
export class FarmermyrequestComponent implements OnInit {
  requests: Request[] = [];
  request: Request = {};
  searchText: string = "";
  filter: string[] = ['All', 'Pending', 'Approved', 'Rejected'];
  filteringData: string = '';
  id: number;
  chemicalId:number=0;
  showDeleteModal:boolean=false;
  requestIdToDelete: number | null = null;
 
  constructor(private router: Router,
              private requestService: RequestService,
              private userService: AuthService,
              private cropService: CropService,
              private agroChemicalService: AgrochemicalService,
              private activatedRoute: ActivatedRoute) {}
 
  ngOnInit(): void {
    const userObjectLocalStorage = localStorage.getItem('authUser');
    const userObject = JSON.parse(userObjectLocalStorage);
    const id = userObject.userId;
    this.requestService.getRequestsByUserId(id).subscribe(data => {
      this.requests = data;
      for (let item of this.requests) {
        const feedbackGiven = localStorage.getItem(`feedbackGiven_${item.requestId}`);
        item.ind = feedbackGiven !== 'true';
      }
      console.log(this.requests);
    });
  }
 
 
  public filtering() {
    const userObjectLocalStorage = localStorage.getItem('authUser');
    const userObject = JSON.parse(userObjectLocalStorage);
    const id = userObject.userId;
    this.requestService.getRequestsByUserId(id).subscribe(data => {
      this.requests = data;
      this.requests = this.requests.filter(r => JSON.stringify(r).includes(this.searchText));
    });
  }
 
  public filteringStatus() {
    const userObjectLocalStorage = localStorage.getItem('authUser');
    const userObject = JSON.parse(userObjectLocalStorage);
    const id = userObject.userId;
    this.requestService.getRequestsByUserId(id).subscribe(data => {
      this.requests = data;
      if (this.filteringData != "All") {
        this.requests = this.requests.filter(p => p.status.toLowerCase() == this.filteringData.toLowerCase());
      }
    });
  }

 
deleteRequest() {
    if (this.requestIdToDelete != null) {
        this.requestService.deleteRequest(this.requestIdToDelete).subscribe(data => {
            this.ngOnInit();
            Swal.fire({
                title: "Deleted!",
                text: "Your request has been deleted successfully.",
                icon: "success",
                confirmButtonColor: "#28a745"
            });
        });
    }
    this.closeDeleteModal();
}

openDeleteModal(requestId: number): void {
    this.requestIdToDelete = requestId;
    Swal.fire({
        title: 'Are you sure?',
        text: 'You won\'t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            this.deleteRequest();
        }
    });
}

disableButton(requestId: number) {
    for (let request of this.requests) {
        if (request.requestId === requestId) {
            request.ind = false;
            localStorage.setItem(`feedbackGiven_${requestId}`, 'true');
            break;
        }
    }
    this.requestService.getRequestById(requestId).subscribe(data => {
        this.chemicalId = data.agroChemical.agroChemicalId;
        this.router.navigate(['/farmer/add/feedback/']);
    });
}
 
  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.requestIdToDelete = null;
  }
 
  
 
}
 
