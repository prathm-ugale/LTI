import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AgroChemical } from 'src/app/models/agrochemical.model';
import { AgrochemicalService } from 'src/app/services/agrochemical.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sellereditchemical',
  templateUrl: './sellereditchemical.component.html',
  styleUrls: ['./sellereditchemical.component.css']
})
export class SellereditchemicalComponent implements OnInit {

  agroChemicalEditedForm: FormGroup;
  id: number = 0;
  agroChemical: AgroChemical = {
    name: '',
    brand: '',
    category: '',
    description: '',
    unit: '',
    pricePerUnit: 0,
    coverImage: undefined
  };

  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private agroChemicalService: AgrochemicalService,
    private router: Router
  ) {
    this.agroChemicalEditedForm = this.formBuilder.group({
      agroChemicalId: [''],
      name: ['', Validators.required],
      brand: ['', Validators.required],
      category: ['', Validators.required],
      description: ['', Validators.required],
      unit: ['', Validators.required],
      pricePerUnit: ['', [Validators.required,Validators.min(1)]],
      image: ['', Validators.required],
      quantity: ['', [Validators.required,Validators.min(0)]]
    });
  }

  updateChemical() {
    if (this.agroChemicalEditedForm.valid) {
      let editedAgroChemical: AgroChemical = this.agroChemicalEditedForm.value;
      this.agroChemicalService.updateAgroChemical(this.id, editedAgroChemical).subscribe(() => {
        Swal.fire({
          title: 'Updated Successfully!',
          text: 'The AgroChemical details have been updated successfully.',
          icon: 'success',
          confirmButtonColor: '#28a745'
        }).then(() => {
          this.router.navigate(['/seller/view/chemical']);
        });
      });
    }
  }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(data => {
      this.id = parseInt(data.get('id'));
      this.agroChemicalService.getAgroChemical(this.id).subscribe(data => {
        this.agroChemical = data;
        this.agroChemicalEditedForm.setValue(this.agroChemical);
      });
    });
  }

  public get name() {
    return this.agroChemicalEditedForm.get('name');
  }

  public get brand() {
    return this.agroChemicalEditedForm.get('brand');
  }

  public get category() {
    return this.agroChemicalEditedForm.get('category');
  }

  public get description() {
    return this.agroChemicalEditedForm.get('description');
  }

  public get unit() {
    return this.agroChemicalEditedForm.get('unit');
  }

  public get pricePerUnit() {
    return this.agroChemicalEditedForm.get('pricePerUnit');
  }

  public get image() {
    return this.agroChemicalEditedForm.get('image');
  }

  public get quantity() {
    return this.agroChemicalEditedForm.get('quantity');
  }
}
