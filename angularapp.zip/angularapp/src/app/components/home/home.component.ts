import { Component, HostListener, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';
import { UserStoreService } from 'src/app/helpers/user-store.service';
import { Subscription } from 'rxjs';
 
 
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
  email: string = '';
  selectedLanguage: string = 'en';
  hideDropdown = false;
 
  isLoggedIn = false;
  userRole: string | null = null;
  username: string | null = null;
 
  languages = [
    { code: 'en', name: 'English' },
    { code: 'mr', name: 'Marathi' },
    { code: 'hi', name: 'Hindi' },
    { code: 'or', name: 'Odia' },
    { code: 'te', name: 'Telugu' },
    { code: 'ta', name: 'Tamil' },
    { code: 'kn', name: 'Kannada' },
    { code: 'ml', name: 'Malayalam' }
 
  ];
 
  private userSubscription: Subscription | null = null;
 
 
  constructor(public service: AuthService, private translate: TranslateService, private authService: AuthService,private userStore: UserStoreService) {
    this.selectedLanguage = localStorage.getItem('language') || 'en';
    this.translate.use(this.selectedLanguage);
  }
 
  showComingSoon() {
    Swal.fire({
      title: 'Coming Soon!',
      text: 'The chat feature will be available soon. Stay tuned!',
      icon: 'info',
      confirmButtonText: 'OK',
      background: 'white',
      color: '#28a745',
      confirmButtonColor: '#28a745',
      customClass: {
        popup: 'shadow-lg rounded',
        title: 'fw-bold',
        confirmButton: 'btn btn-success',
      }
    });
  }
 
  ngOnInit(): void {
    this.updateUserState();
 
    this.userSubscription = this.userStore.user$.subscribe(() => {
      this.updateUserState();
    });
  }
 
  
  changeLanguage(languageCode: string) {
    this.selectedLanguage = languageCode;
    this.translate.use(languageCode);
    localStorage.setItem('language', languageCode);
  }
 
 
  private updateUserState(): void {
    this.isLoggedIn = this.userStore.isLoggedIn();
    this.username = this.userStore.authUser?.userName;
    this.userRole = this.userStore.authUser?.role || null;
  }
 
  
  galleryImages = [
    { src: '/assets/home_images6/gallery1.jpg', alt: 'Gallery Image 1' },
    { src: '/assets/home_images6/gallery2.jpg', alt: 'Gallery Image 2' },
    { src: '/assets/home_images6/gallery3.jpg', alt: 'Gallery Image 3' },
    { src: '/assets/home_images6/gallery4.jpg', alt: 'Gallery Image 4' },
    { src: '/assets/home_images6/gallery5.jpg', alt: 'Gallery Image 5' },
    { src: '/assets/home_images6/gallery6.jpg', alt: 'Gallery Image 6' }
  ];
 
  
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollToTopButton = document.querySelector('.scroll-to-top');
    if (window.scrollY > 200) {
      scrollToTopButton?.classList.add('visible');
    } else {
      scrollToTopButton?.classList.remove('visible');
    }
 
    
    const heroSection = document.querySelector('.hero-section');
    const heroBottom = heroSection ? heroSection.getBoundingClientRect().bottom : 0;
    this.hideDropdown = heroBottom <= 50;
  }
 
  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
 

  zoomImage(image: any) {
    console.log('Zoomed:', image.src);
  }
 
  
  onSubmit(form: any) {
    if (form.valid) {
      this.email = form.value.email;
 
      Swal.fire({
        title: this.translate.instant('THANK_YOU'),
        text: this.translate.instant('SUBSCRIBED', { email: this.email }) ||
              `You have successfully subscribed to our newsletter with email: ${this.email}. Stay tuned for the latest updates!`,
        icon: 'success',
        confirmButtonText: this.translate.instant('OK') || 'OK',
        background: 'linear-gradient(to right, #28a745, #218838)',
        color: '#ffffff',
        confirmButtonColor: '#155724',
        customClass: {
          popup: 'shadow-lg rounded',
          title: 'fw-bold',
          confirmButton: 'btn btn-success',
        }
      });
 
      form.reset();
    }
  }
 
}

