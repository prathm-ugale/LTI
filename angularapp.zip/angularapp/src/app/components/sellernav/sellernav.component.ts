import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellernav',
  templateUrl: './sellernav.component.html',
  styleUrls: ['./sellernav.component.css']
})
export class SellernavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
