import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farmernav',
  templateUrl: './farmernav.component.html',
  styleUrls: ['./farmernav.component.css']
})
export class FarmernavComponent implements OnInit {

  userfromLocalStorage = localStorage.getItem('authUser');
 

  userObject = JSON.parse(this.userfromLocalStorage);
  userIdfromLocal = parseInt(this.userObject.userId);
  constructor() { }

  ngOnInit(): void {
  }

  
 
}
