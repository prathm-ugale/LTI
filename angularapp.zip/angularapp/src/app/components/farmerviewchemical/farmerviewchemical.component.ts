import { Component, OnInit } from '@angular/core';
import { Request } from 'src/app/models/request.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AgroChemical } from 'src/app/models/agrochemical.model';
import { Crop } from 'src/app/models/crop.model';
import { AgrochemicalService } from 'src/app/services/agrochemical.service';
import { CropService } from 'src/app/services/crop.service';
import { RequestService } from 'src/app/services/request.service';
import Swal from 'sweetalert2';
 
@Component({
  selector: 'app-farmerviewchemical',
  templateUrl: './farmerviewchemical.component.html',
  styleUrls: ['./farmerviewchemical.component.css']
})
export class FarmerviewchemicalComponent implements OnInit {
 
 
 
  chemicals:AgroChemical[]=[];
  navigateId:number=0
  isRequest:boolean=false;
  crops:Crop[]=[];
  requestForm:FormGroup;
  chemicalDetails:boolean=false;
  agroChemical:AgroChemical={
    name: '',
    brand: '',
    category: '',
    description: '',
    unit: '',
    pricePerUnit: 0
  }
  chemicalQuantity:number=0;
 
                 
 
  constructor(private requestService:RequestService,private agroChemicalService:AgrochemicalService,private cropService:CropService,private formBuilder:FormBuilder, private router:Router) {
      this.requestForm=formBuilder.group({
        cropName:formBuilder.control("",Validators.required),
        quantity:formBuilder.control("",Validators.required)
      })
   }
 
  ngOnInit(): void {
   this.getAllAgroChemicals();
  this.getAllCrops();
  }
 
  getAllCrops(){
    const userfromLocalStorage=localStorage.getItem('authUser');
    const userObject=JSON.parse(userfromLocalStorage);
    let id= userObject.userId;
    this.cropService.getCropByUserId(id).subscribe(data=>{
      console.log(data);
      this.crops=data;
 
    })
  }
 
  getAllAgroChemicals(){
    this.agroChemicalService.getAllAgroChemicals().subscribe(data=>{
      this.chemicals=data;
      this.chemicals=this.chemicals.filter(b=>b.quantity>0);
    })
  }
 
  passChemicalId(id:number){
    if(this.crops.length==0){
      alert("Add the crop")
    }
    else{
    console.log(id);
     this.navigateId=id;
     this.agroChemicalService.getAgroChemical(this.navigateId).subscribe(data=>{
       this.chemicalQuantity=data.quantity
     })
     console.log(this.navigateId);
     this.isRequest=true;
    }
  }
 
  getChemicals(chemicalId:number){
    this.agroChemicalService.getAgroChemical(chemicalId).subscribe(data=>{
      this.chemicalDetails=true;
      this.agroChemical=data;
    })
  }
 
 
 
  filter(findData:string){
    this.agroChemicalService.getAllAgroChemicals().subscribe(data=>{
       this.chemicals=data;
       this.chemicals=this.chemicals.filter(b=>b.quantity>0);
       this.chemicals=this.chemicals.filter((b)=>(b.name.toLowerCase().includes(findData.toLowerCase())
       || b.brand.toLowerCase().includes(findData.toLowerCase()) ||
        b.category.toLowerCase().includes(findData.toLowerCase()) ))
    })
  }
 
  addRequest() {
    if (this.requestForm.valid) {
      console.log(this.requestForm.value.cropName);
      console.log(this.requestForm.value.quantity);
      
      let cid: number = parseInt(this.requestForm.value.cropName);
      let q: number = this.requestForm.value.quantity;
      
      const userObjectLocalStorage = localStorage.getItem('authUser');
      const userObject = JSON.parse(userObjectLocalStorage);
      const id = userObject.userId;
  
      let newRequest: Request = {
        agroChemical: {
          agroChemicalId: this.navigateId,
        },
        user: {
          userId: id,
        },
        crop: {
          cropId: cid,
        },
        quantity: q,
        status: 'Pending',
        requestDate: new Date(),
      };
  
      console.log(newRequest);
  
      
      if (q > this.chemicalQuantity) {
        Swal.fire({
          title: 'Invalid Quantity!',
          text: 'Please enter a quantity within the available stock.',
          icon: 'warning',
          confirmButtonColor: '#dc3545',
        });
      } else {
        this.requestService.addRequest(newRequest).subscribe(
          (data) => {
            
            Swal.fire({
              title: 'Success!',
              text: 'Request has been placed successfully!',
              icon: 'success',
              confirmButtonColor: '#28a745',
            }).then(() => {
              this.router.navigate(['/farmer/myRequest']);
            });
          },
          (error) => {
            
            Swal.fire({
              title: 'Error!',
              text: 'Something went wrong. Please try again.',
              icon: 'error',
              confirmButtonColor: '#dc3545',
            });
          }
        );
      }
    }
  }
  
 
}
 
 