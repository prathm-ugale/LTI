import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CropService } from 'src/app/services/crop.service';
import { noFutureDateValidator } from 'src/app/validators/custom-validators';
 
@Component({
  selector: 'app-farmereditcrop',
  templateUrl: './farmereditcrop.component.html',
  styleUrls: ['./farmereditcrop.component.css']
})
export class FarmereditcropComponent implements OnInit {
 
 
  cropFrom:FormGroup
  cropID:number
  typesOfCrop:String[]=['Vegetables','Pulses','Grains','Fruits']
  vegetables:String[]=["Lettuce", "Cabbage", "Coriander", "Mint", "Broccoli", "Cucumber", "Carrot", "Onion", "Peas", "Ginger", "Cauliflower", "Beetroot", "Ladyfinger"]
  grains:String[]=["Rice", "Wheat", "Rye", "Oats", "Barley", "Millet", "Maize"]
  pulses:String[]=["Toor Dal", "Chana Dal", "Urad Dal", "Masoor Dal", "Rajma", "Chickpeas" , "Soy Bean", "Moong Dal" ]
  fruits:String[]=["Banana", "Apple", "Strawberry", "Avocado", "Pineapple", "Watermelon", "Mango", "Kiwi", "Orange", "Berry", "Blueberry", "Cherry", "Lemon", "Apricot", "Figs", "Plum", "Papaya", "Grapefruit"]
  dataToDisplay:String[]=["Lettuce", "Cabbage", "Coriander", "Mint", "Broccoli", "Cucumber", "Carrot", "Onion", "Peas", "Ginger", "Cauliflower", "Beetroot", "Ladyfinger","Rice", "Wheat", "Rye", "Oats", "Barley", "Millet", "Maize","Toor Dal", "Chana Dal", "Urad Dal", "Masoor Dal", "Rajma", "Chickpeas" , "Soy Bean", "Moong Dal","Banana", "Apple", "Strawberry", "Avocado", "Pineapple", "Watermelon", "Mango", "Kiwi", "Orange", "Berry", "Blueberry", "Cherry", "Lemon", "Apricot", "Figs", "Plum", "Papaya", "Grapefruit"]
 
  constructor(private cropService:CropService,private formBuilder:FormBuilder,private router:Router,private activatedRoute:ActivatedRoute) {
 
    this.cropFrom=formBuilder.group({
      cropId:formBuilder.control("",Validators.required),
      cropName:formBuilder.control("",Validators.required), 
      cropType:formBuilder.control("",Validators.required),
      description:formBuilder.control("",Validators.required),
      plantingDate:formBuilder.control("", [Validators.required, noFutureDateValidator()]) 
    })
 
   }
 
   ngOnInit(): void {
 
    this.activatedRoute.paramMap.subscribe(data=>{
      this.cropID=parseInt(data.get('id'))
      this.cropService.getCropById(this.cropID).subscribe(data=>{
        const formattedData = { ...data, plantingDate: this.formatDate(data.plantingDate) };
        this.cropFrom.setValue(formattedData);
      })
    })
  }
 

private formatDate(date: string): string {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = ('0' + (d.getMonth() + 1)).slice(-2);
  const day = ('0' + d.getDate()).slice(-2);
  return `${year}-${month}-${day}`;
}

 
  updateCrop(){
 
    if(this.cropFrom.valid){
      this.cropService.updateCrop(this.cropID,this.cropFrom.value).subscribe(data=>{
        this.router.navigate(["/farmer/view/crop"])
      })
    }
 
  }
 
  public get cropName(){
 
    return this.cropFrom.get('cropName');
 
  }
 
  public get cropType(){
 
    return this.cropFrom.get('cropType');
 
  }
 
  public get description(){
 
    return this.cropFrom.get('description');
 
  }
 
  public get plantingDate(){
 
    return this.cropFrom.get('plantingDate');
  }

  displayCrops(arg: String) {
    if(arg=='Vegetables'){
      this.dataToDisplay=this.vegetables;
    }else if(arg=='Pulses'){
      this.dataToDisplay=this.pulses;
    }else if(arg=='Grains'){
      this.dataToDisplay=this.grains;
    }else if(arg=='Fruits'){
      this.dataToDisplay=this.fruits;
    }
  }
 
}
