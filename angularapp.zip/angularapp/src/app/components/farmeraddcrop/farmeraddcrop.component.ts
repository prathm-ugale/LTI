import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Crop } from 'src/app/models/crop.model';
import { CropService } from 'src/app/services/crop.service';
import { noFutureDateValidator } from 'src/app/validators/custom-validators';
 
@Component({
  selector: 'app-farmeraddcrop',
  templateUrl: './farmeraddcrop.component.html',
  styleUrls: ['./farmeraddcrop.component.css']
})
export class FarmeraddcropComponent implements OnInit {
 
  cropFrom:FormGroup
  typesOfCrop:string[]=['Vegetables','Pulses','Grains','Fruits']
  vegetables:string[]=["Lettuce", "Cabbage", "Coriander", "Mint", "Broccoli", "Cucumber", "Carrot", "Onion", "Peas", "Ginger", "Cauliflower", "Beetroot", "Ladyfinger"]
  grains:string[]=["Rice", "Wheat", "Rye", "Oats", "Barley", "Millet", "Maize"]
  pulses:string[]=["Toor Dal", "Chana Dal", "Urad Dal", "Masoor Dal", "Rajma", "Chickpeas" , "Soy Bean", "Moong Dal" ]
  fruits:string[]=["Banana", "Apple", "Strawberry", "Avocado", "Pineapple", "Watermelon", "Mango", "Kiwi", "Orange", "Berry", "Blueberry", "Cherry", "Lemon", "Apricot", "Figs", "Plum", "Papaya", "Grapefruit"]
  dataToDisplay:string[]=[];

  constructor(private cropService:CropService,private formBuilder:FormBuilder,private router:Router) {
 
    this.cropFrom=formBuilder.group({
      cropName:formBuilder.control("",Validators.required), 
      cropType:formBuilder.control("",Validators.required),
      description:formBuilder.control("",Validators.required),
      plantingDate:formBuilder.control("", [Validators.required, noFutureDateValidator()]) 
    })
 
   }

   
 
  ngOnInit(): void {
  }

 
  addCrop(){
    if(this.cropFrom.valid){
     let userfromLocalStorage=localStorage.getItem('authUser')
     let userObject=JSON.parse(userfromLocalStorage)
     let cropData:Crop={
       user: {
         userId: userObject.userId,
         email:'' ,
         password: '',
         username: '',
         mobileNumber: '',
         userRole: ''
       },
       cropName: this.cropFrom.value.cropName,
       cropType: this.cropFrom.value.cropType,
       description: this.cropFrom.value.description,
       plantingDate: this.cropFrom.value.plantingDate
     }
      console.log(cropData);
      this.cropService.addCrop(cropData).subscribe(data=>{
        this.router.navigate(["/farmer/view/crop"])
      },(error)=>{
        alert('same plant exists on same Planting Date!');
      })
 
    }

  }
  
  displayCrops(data){
    console.log(data);
   if(data=='Fruits'){
     this.dataToDisplay=this.fruits;
   }
   else if(data=='Vegetables'){
    this.dataToDisplay=this.vegetables
   }
   else if (data=='Grains'){
    this.dataToDisplay=this.grains;
   }
   else if(data=='Pulses'){
    this.dataToDisplay=this.pulses;
   }
  }
 
  public get cropName(){
 
    return this.cropFrom.get('cropName');
 
  }
 
  public get cropType(){
 
    return this.cropFrom.get('cropType');
 
  }
 
  public get description(){
 
    return this.cropFrom.get('description');
 
  }
 
  public get plantingDate(){
 
    return this.cropFrom.get('plantingDate');
  }

  
 
}
