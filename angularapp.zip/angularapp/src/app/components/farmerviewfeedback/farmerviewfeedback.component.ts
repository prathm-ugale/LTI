import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import Swal from 'sweetalert2';
 
@Component({
  selector: 'app-farmerviewfeedback',
  templateUrl: './farmerviewfeedback.component.html',
  styleUrls: ['./farmerviewfeedback.component.css']
})
export class FarmerviewfeedbackComponent implements OnInit {
 
  feedbacks: Feedback[] = [];
  userfromLocalStorage = localStorage.getItem('authUser');
 
  userObject = JSON.parse(this.userfromLocalStorage);
  userIdfromLocal = parseInt(this.userObject.userId);
 
  constructor(
    private feedbackService: FeedbackService,
    private router: Router,
    
  ) {}
 
  ngOnInit(): void {
    this.getAllFeedbacks(this.userIdfromLocal);
  }
 
  getAllFeedbacks(id: number | null): void {
    if (id !== null) {
      this.feedbackService.getAllFeedbacksByUserId(id).subscribe(data => {
        this.feedbacks = data;
      }, error => {
        console.error('Error loading feedback:', error);
      });
    } else {
      console.error('User ID is null');
    }
  }
 
 
deleteFeedback(id: number): void {
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#2e7d32', 
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!',
    background: '#e8f5e9', 
  }).then((result) => {
    if (result.isConfirmed) {
      this.feedbackService.deleteFeedback(id).subscribe(response => {
        this.feedbacks = this.feedbacks.filter(feedback => feedback.feedbackId !== id);
       
        Swal.fire({
          title: 'Deleted!',
          text: 'Your feedback has been deleted.',
          icon: 'success',
          background: '#e8f5e9', 
          confirmButtonColor: '#2e7d32', 
        });
      });
    }
  });
}
 
 
}
 