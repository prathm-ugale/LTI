import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgroChemical } from 'src/app/models/agrochemical.model';
import { Crop } from 'src/app/models/crop.model';
import { Request } from 'src/app/models/request.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { RequestService } from 'src/app/services/request.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-sellerviewrequests',
  templateUrl: './sellerviewrequests.component.html',
  styleUrls: ['./sellerviewrequests.component.css']
})
export class SellerviewrequestsComponent implements OnInit {
 
  searchText:string="";
  selectedUser:User;
  requests:Request[]=[];
  request:Request={
    agroChemical: {
      name: '',
      brand: '',
      category: '',
      description: '',
      unit: '',
      pricePerUnit: 0
    },
    user:{
      email: '',
      password: '',
      username: '',
      mobileNumber: '',
      userRole: ''
    },
    crop: {
      cropName: '',
      cropType: '',
      description: '',
      plantingDate: ''
    },
    quantity: 0,
    status: '',
    requestDate:null,
   
  }
  isShowData:boolean=false;
  filter:string[]=['All','Pending','Approved','Rejected'];
  filteringData:string='';
 
 
  constructor(private requestService:RequestService,private authService:AuthService,private router:Router) { }
 
 
  ngOnInit(): void {
   
    this.requestService.getAllRequest().subscribe(data=>{
      this.requests=data;
    })
  }
 
  public displayUser(userId:number){
    this.requestService.getRequestsByUserId(userId).subscribe(data=>{
 
      this.requests=data;
      this.isShowData=true;
 
    })
  }
  public filtering()
  {
    this.requestService.getAllRequest().subscribe(data=>{
      this.requests=data;
      this.requests=this.requests.filter(r=>JSON.stringify(r).includes(this.searchText));
    })
  }

 


public approved(id: number, status: string) {
    Swal.fire({
        title: 'Approve Request?',
        text: "Are you sure you want to approve this request?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Approve!'
    }).then((result) => {
        if (result.isConfirmed) {
            this.requestService.getRequestById(id).subscribe(data => {
                this.request = data;
                this.request.status = status;
                this.requestService.updateRequestStatus(id, this.request).subscribe(data => {
                    this.ngOnInit();
                    Swal.fire('Approved!', 'The request has been approved.', 'success');
                });
            });
        }
    });
}

public rejected(id: number, status: string) {
    Swal.fire({
        title: 'Reject Request?',
        text: "Are you sure you want to reject this request?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Reject!'
    }).then((result) => {
        if (result.isConfirmed) {
            this.requestService.getRequestById(id).subscribe(data => {
                this.request = data;
                this.request.status = status;
                this.requestService.updateRequestStatus(id, this.request).subscribe(data => {
                    this.ngOnInit();
                    Swal.fire('Rejected!', 'The request has been rejected.', 'success');
                });
            });
        }
    });
}


public showMore(id: number) {
  console.log("Fetching details for request ID:", id); 

  this.requestService.getRequestById(id).subscribe(
      (data) => {
          console.log("Received request details:", data); 
          this.request = data;
          this.isShowData = true; 
      },
      (error) => {
          console.error("Error fetching request details:", error);
      }
  );
}

public close() {
  this.isShowData = false; 
}

 
  public filteringStatus()
  {
    this.requestService.getAllRequest().subscribe(data=>{
      this.requests=data;
     if(this.filteringData!="All")
    this.requests=this.requests.filter(p=>p.status.toLowerCase()==this.filteringData.toLowerCase());
   
   
 
 
    })
   
 
  }

  
  
  
 
 
}
 