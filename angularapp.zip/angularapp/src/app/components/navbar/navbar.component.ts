import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserStoreService } from 'src/app/helpers/user-store.service';
import { AuthService } from 'src/app/services/auth.service';
import { Subscription } from 'rxjs';
import Swal from 'sweetalert2';
declare var bootstrap: any; 
 
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy, AfterViewInit {
  isLoggedIn = false;
  userRole: string | null = null;
  username: string | null = null;
 
  private userSubscription: Subscription | null = null;
 
  constructor(
    private authService: AuthService,
    private router: Router,
    private userStore: UserStoreService
  ) {}
 
  ngOnInit(): void {
    this.updateUserState();
 
    this.userSubscription = this.userStore.user$.subscribe(() => {
      this.updateUserState();
    });
  }
 
  ngAfterViewInit(): void {
   
    setTimeout(() => {
      const dropdownElement = document.getElementById('userDropdown');
      if (dropdownElement) {
        new bootstrap.Dropdown(dropdownElement);
      }
    }, 500);
  }
 
  private updateUserState(): void {
    this.isLoggedIn = this.userStore.isLoggedIn();
    this.username = this.userStore.authUser?.userName;
    this.userRole = this.userStore.authUser?.role || null;
  }
 
 
 
  logout(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: 'Do you want to log out?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#28a745',
      cancelButtonColor: '#dc3545',
      confirmButtonText: 'Yes, log out!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.authService.logout();
        this.router.navigate(['/login']);
      }
    });
  }
 
 
  ngOnDestroy(): void {
    if (this.userSubscription) {
      this.userSubscription.unsubscribe();
    }
  }
}