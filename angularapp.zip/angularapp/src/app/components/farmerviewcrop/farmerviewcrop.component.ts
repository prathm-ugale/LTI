import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Crop } from 'src/app/models/crop.model';
import { CropService } from 'src/app/services/crop.service';
 
@Component({
  selector: 'app-farmerviewcrop',
  templateUrl: './farmerviewcrop.component.html',
  styleUrls: ['./farmerviewcrop.component.css']
})
export class FarmerviewcropComponent implements OnInit {
 
  constructor(private cropService:CropService,private router:Router) { }
 
  crops:Crop[]=[]
  searchParameter:string;
  showDeleteModal:boolean=false;
  cropIdToDelete: number | null = null;
 
 
colors: string[] = ['#90a955','#4f772d'];
 
  ngOnInit(): void {
    this.getCrops();
  }
 
  getCrops(){
    const userfromLocalStorage=localStorage.getItem('authUser');
    const userObject=JSON.parse(userfromLocalStorage);
    let id=userObject.userId;
    this.cropService.getCropByUserId(id).subscribe(data=>{
      this.crops=data;
    })
  }
 
  deleteCrop(id:number){
    this.cropService.deleteCrop(id).subscribe(data=>{
      this.getCrops();
    })
  }
 
  searchByCrop(){
    const userfromLocalStorage=localStorage.getItem('authUser');
    const userObject=JSON.parse(userfromLocalStorage);
    let id=userObject.userId;
    this.cropService.getCropByUserId(id).subscribe(data=>{
      this.crops=data;
      this.crops=this.crops.filter(f=>{
        return f.cropName.includes(this.searchParameter)||f.cropType.includes(this.searchParameter)||f.plantingDate.includes(this.searchParameter)
      })
    })
 
   
  }
 
  openDeleteModal(cropId: number): void {
    this.cropIdToDelete = cropId;
    this.showDeleteModal = true;
  }
  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.cropIdToDelete = null;
  }
 
  confirmDelete(): void {
    if (this.cropIdToDelete != null) {
      this.cropService.deleteCrop(this.cropIdToDelete).subscribe(data=>{
        this.getCrops();
      })
    }
    this.closeDeleteModal();
  }
 
}
 