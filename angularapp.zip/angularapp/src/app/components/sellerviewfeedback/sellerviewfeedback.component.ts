import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';
 
@Component({
  selector: 'app-sellerviewfeedback',
  templateUrl: './sellerviewfeedback.component.html',
  styleUrls: ['./sellerviewfeedback.component.css']
})
export class SellerviewfeedbackComponent implements OnInit {
 
  farmerId: number = 0;
  feedbacks: Feedback[] = [];
  user: User;
  userDisplay: boolean = false;
  feedbackList: Feedback[] = [];
  selectedUser: User | null = null;
  showProfileModal: boolean = false;
  numericId: Number;
 
  constructor(
    private feedbackService: FeedbackService,
    private router: Router,
    private authService: AuthService
  ) {}
 
  ngOnInit(): void {
    this.loadFeedback();
  }
 
  loadFeedback(): void {
    this.feedbackService.getFeedbacks().subscribe(feedback => {
      console.log(feedback); 
      this.feedbackList = feedback;
    }, error => {
      console.error('Error loading feedback:', error);
    });
  }
 
  public viewFeedbackByFarmerId(id: number) {
    let userId: string | null = localStorage.getItem('userId');
    let numericId: number | null = userId !== null ? Number(userId) : null;
 
    console.log("---------", numericId);
 
    this.feedbackService.getAllFeedbacksByUserId(numericId).subscribe(data => {
      console.log("+++++++++++++++", userId);
      this.feedbacks = data;
    })
  }
 
  displayUserProfile(userId: number): void {
    this.authService.getUserById(userId).subscribe(data => {
      this.selectedUser = data;
      this.showProfileModal = true;
    })
  }
 
  closeProfile(): void {
    this.showProfileModal = false;
    this.selectedUser = null;
  }
 
  public formatDate(date: string): string {
    const d = new Date(date);
    return d.toISOString().split('T')[0];
  }
}