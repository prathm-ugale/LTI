package com.examly.springapp.service;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.examly.springapp.exceptions.FeedbackNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.FeedbackRepo;
import com.examly.springapp.repository.UserRepo;
 
@Service

public class FeedbackServiceImpl implements FeedbackService {
 
    @Autowired
    private FeedbackRepo feedbackRepo;
 
    @Autowired
    private UserRepo userRepo;
 
    @Override
    public List<Feedback> viewFeedback() {
        List<Feedback> feedbackList = feedbackRepo.findAll();
        if(feedbackList.isEmpty()) {
            throw new FeedbackNotFoundException("Feedbacks not available.");
        }
        return feedbackList;
    }
 
    @Override
    public Feedback addFeedback(Feedback feedback) {
        User user = userRepo.findById(feedback.getUser().getUserId()).orElse(null);
        feedback.setUser(user);
        return feedbackRepo.save(feedback);
    }
 
    @Override
    public List<Feedback> getFeedbackByUserId(Integer userId) {
        Optional<User> optUser = userRepo.findById(userId);
        if(optUser.isEmpty()) {
            throw new UserNotFoundException("User Not Found");
        }
        User user = optUser.get();
        List<Feedback> optionalUser = feedbackRepo.findByUser(user);
        if(optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found by Feedback");
        }
        return optionalUser;
    }
 
    @Override
    public Feedback deleteFeedback(int feedbackId) {
        Optional<Feedback> opt = feedbackRepo.findById(feedbackId);
        if(opt.isEmpty()) {
            throw new FeedbackNotFoundException("Feedback Not Found");
        }
        feedbackRepo.deleteById(feedbackId);
        return null;
    }
}