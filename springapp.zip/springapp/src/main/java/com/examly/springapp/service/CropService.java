package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Crop;

public interface CropService {

    Crop addCrop(Crop crop);

    List<Crop> getAllCrop();

    List<Crop> getCropByUserId(int userId);

    Crop getCropById(Long cropId);

    Crop updateCropById(Long cropId,Crop crop);

    Crop deleteCropById(Long cropId);

}
