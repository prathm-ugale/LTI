package com.examly.springapp.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.examly.springapp.exceptions.AgroChemicalNotFoundException;
import com.examly.springapp.exceptions.DuplicateAgroChemicalException;
import com.examly.springapp.model.AgroChemical;
import com.examly.springapp.repository.AgroChemicalRepo;

@Service

public class AgroChemicalServiceImpl implements AgroChemicalService {

    @Autowired
    private AgroChemicalRepo agroChemicalRepo;

    
    @Override
    public AgroChemical addAgroChemical(AgroChemical agroChemical) {
       AgroChemical getAgroChemical= agroChemicalRepo.findByNameAndBrand(agroChemical.getName(), agroChemical.getBrand()).orElse(null);
       if(getAgroChemical!=null){
         throw new DuplicateAgroChemicalException("AgroChemical with name and brand already exits!");
       }
      AgroChemical agrochemicals = agroChemicalRepo.save(agroChemical);
      agrochemicals.setImage("agrochemical"+agrochemicals.getAgroChemicalId()+".jpeg");
      return agroChemicalRepo.save(agrochemicals);
    }

    @Override
    public AgroChemical getAgroChemicalById(long id) {
       Optional<AgroChemical> getAgroChemical = agroChemicalRepo.findById(id);
       if(getAgroChemical.isEmpty()){
         throw new AgroChemicalNotFoundException("AgroChemical with ID:"+id+" not found");
       }
       return getAgroChemical.get();
    }

    @Override
    public List<AgroChemical> getAllAgroChemicals() {
      List<AgroChemical> getAllAgroChemicals = agroChemicalRepo.findAll();
      return getAllAgroChemicals;  
    }

    @Override
    public AgroChemical updateAgroChemical(long id, AgroChemical agroChemical) {
        Optional<AgroChemical> getAgroChemical = agroChemicalRepo.findById(id);
        if(getAgroChemical.isEmpty()){
            throw new AgroChemicalNotFoundException("AgroChemical with ID:"+id+" not found");
          }
        AgroChemical existingAgroChemical=getAgroChemical.get();
        existingAgroChemical.setBrand(agroChemical.getBrand());
        existingAgroChemical.setCategory(agroChemical.getCategory());
        existingAgroChemical.setDescription(agroChemical.getDescription());
        existingAgroChemical.setName(agroChemical.getName());
        existingAgroChemical.setPricePerUnit(agroChemical.getPricePerUnit());
        existingAgroChemical.setUnit(agroChemical.getUnit());
        existingAgroChemical.setImage(agroChemical.getImage());
        existingAgroChemical.setQuantity(agroChemical.getQuantity());
        return agroChemicalRepo.save(existingAgroChemical);
    }

    @Override
    public void deleteAgroChemicl(long id) {
        Optional<AgroChemical> getAgroChemical = agroChemicalRepo.findById(id);
        if(getAgroChemical.isEmpty()){
            throw new AgroChemicalNotFoundException("AgroChemical with ID:"+id+" not found");
          }
        agroChemicalRepo.deleteById(id);      
    }

    public String uploadImage(MultipartFile file) {
      String path = "src/main/resources/static/images";
      File dirFile = new File(path);
      if(!dirFile.exists()){
        dirFile.mkdirs();
      }

      String fileName = file.getOriginalFilename();
      Path filePath = Paths.get(path,fileName);

      try{
        Files.write(filePath, file.getBytes());
      }catch(IOException e){
        System.out.println("Exception Here : "+e);
      }

      return fileName;
    }

 

}
