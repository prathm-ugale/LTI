package com.examly.springapp.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Crop;
import com.examly.springapp.model.User;

@Repository

public interface CropRepo extends JpaRepository<Crop,Long> {
   
   
    public List<Crop> findByUser(User user);
    public Optional<Crop> findByPlantingDateAndCropName(LocalDate data,String crop);

    

}
