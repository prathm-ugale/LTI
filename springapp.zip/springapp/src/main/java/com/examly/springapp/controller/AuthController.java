package com.examly.springapp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.config.JwtUtils;

import com.examly.springapp.model.AuthUser;
import com.examly.springapp.model.User;

import com.examly.springapp.service.UserServiceImpl;

@RestController

@CrossOrigin

public class AuthController {

    @Autowired

    private UserServiceImpl userService;

    @Autowired

    private AuthenticationManager authManager;

    @Autowired
    
    private JwtUtils jwtutils;

    @PostMapping("/api/register")
    @PreAuthorize("permitAll()")
    public ResponseEntity<User> add(@RequestBody User user) throws Exception{
        return ResponseEntity.status(201).body(userService.add(user));
    }


    @PostMapping("/api/login")
    @PreAuthorize("permitAll()")
    
    public ResponseEntity<AuthUser> loginUser(@RequestBody User user) throws Exception{
        return ResponseEntity.status(200).body(userService.loginUser(user));
    }

    @GetMapping("/api/user/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<?> getUserById(@PathVariable int userId){
        System.out.println("===================================");
        System.out.println("===================================");
        System.out.println("===================================");
        return ResponseEntity.status(200).body(userService.getUserById(userId));
    }


    



}
