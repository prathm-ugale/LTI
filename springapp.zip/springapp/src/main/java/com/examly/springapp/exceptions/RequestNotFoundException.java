package com.examly.springapp.exceptions;

public class RequestNotFoundException extends RuntimeException{

    public RequestNotFoundException()
    {

    }

    public RequestNotFoundException(String msg)
    {
        super(msg);
    }
    
}
