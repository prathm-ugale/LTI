package com.examly.springapp.exceptions;

public class AgroChemicalsException extends RuntimeException{
    
    public AgroChemicalsException(){

    }

    public AgroChemicalsException(String msg){
       super(msg);
    }
}
